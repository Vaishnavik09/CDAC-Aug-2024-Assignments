class ForDemo{

	public static void main(String args[]){

		/*for (int i = 0 ; i<5 ; i++){
			System.out.println("Inside error");
		}	*/
		
		/*for (int i = 0 ; i<=5 ; System.out.println("incre/decre block of for loop")){
			System.out.println("Inside for");
			i++;
		}*/
		/*for (int i = 0 ; 1 ; i++){
			System.out.println("Inside for loop");
		}
		for (int i = 0 ; 0 ; i++){
			System.out.println("Inside for loop");
		}*/
		
		/*int a =10;
		int b = 20;
		 int c =30,d=40;
		*/
		
		int i;
		int j;			  //true,true
		for (i = 0,j=0 ; i<5 && j<5 ; i++,j++){
				System.out.println(i + " " + j);
			
			
			System.out.println("Inside For Loop");
		}
		
		
		/*int i = 0;
		int j = 0;			 
		for (; i<5 && j<5 ; i++,j++){
				System.out.println(i + " " + j);
			
			
			System.out.println("Inside For Loop");
		}*/
	//infinite loop	
	//for(;;){
	//	System.out.println("Inside For Loop");	
	//}
		
		// int i = 0; 
		// for (System.out.print("Init."); i<5 ; i++){
		// 	System.out.println("Inside for loop");
		// }
		
		
		

	}





}